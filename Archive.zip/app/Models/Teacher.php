<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\Blameable;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\Activitylog\LogOptions;

/**
 * Class Teacher
 *
 * @property int $id
 * @property string $employee_id
 * @property int|null $appointment_id
 * @property-read \App\Models\EmployerAppointment|null $appointment
 * @property-read \App\Models\EmployerCurrentAppointment|null $currentAppointment
 * @property-read \App\Models\People|null $employee
 * @property-read \App\Models\TeacherCategory|null $teacherCategory
 * @property-read \App\Models\TeacherType|null $teacherType
 * @property-read \App\Models\MediumOfInstruction|null $medium
 * @property-read \App\Models\ApointedSubject|null $appointmentSubject
 * @property-read \App\Models\SubjectList|null $mainSubject
 * @property-read \App\Models\SubjectList|null $secondarySubject
 * @property-read \App\Models\SubjectList|null $currentTeachingSubject
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\EmployerAppointmentHistory[] $appointmentHistory
 * @property-read \App\Models\EmployerAttachmentAppointment|null $attachmentAppointment
 */
class Teacher extends Model
{
    use HasFactory, LogsActivity, Blameable;

    protected $table = 'teachers';
    protected $primaryKey = 'id';

    protected $fillable = [
        'appointment_id',
        'employee_id',
        'teacher_category',
        'teacher_type',
        'appointment_medium',
        'appointment_subject',
        'main_subject',
        'secondary_subject',
        'current_teaching_subject',
        'created_by',
        'updated_by',
    ];

    /**
     * Relationships
     */

    // Employer appointment
    public function appointment()
    {
        return $this->belongsTo(EmployerAppointment::class, 'appointment_id', 'appointment_id');
    }

    // Current appointment
    public function currentAppointment()
    {
        return $this->belongsTo(EmployerCurrentAppointment::class, 'appointment_id', 'appointment_id');
    }

    // Appointment history
    public function appointmentHistory()
    {
        return $this->belongsTo(EmployerAppointmentHistory::class, 'appointment_id', 'appointment_id');
    }

    // Attachment appointment
    public function attachmentAppointment()
    {
        return $this->belongsTo(EmployerAttachmentAppointment::class, 'appointment_id', 'appointment_id');
    }

    // Related person (employee)
    public function employee()
    {
        return $this->belongsTo(People::class, 'employee_id', 'people_id');
    }

    // Teacher category
    public function teacherCategory()
    {
        return $this->belongsTo(TeacherCategory::class, 'teacher_category', 'categories_id');
    }

    // Teacher type
    public function teacherType()
    {
        return $this->belongsTo(TeacherType::class, 'teacher_type', 'teacher_types_id');
    }

    // Medium of instruction
    public function medium()
    {
        return $this->belongsTo(MediumOfInstruction::class, 'appointment_medium', 'medium_id');
    }

    // Appointment subject
    public function appointmentSubject()
    {
        return $this->belongsTo(ApointedSubject::class, 'appointment_subject', 'a_subject_id');
    }

    // Main subject
    public function mainSubject()
    {
        return $this->belongsTo(SubjectList::class, 'main_subject', 'subject_id');
    }

    // Secondary subject
    public function secondarySubject()
    {
        return $this->belongsTo(SubjectList::class, 'secondary_subject', 'subject_id');
    }

    // Current teaching subject
    public function currentTeachingSubject()
    {
        return $this->belongsTo(SubjectList::class, 'current_teaching_subject', 'subject_id');
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logAll()
            ->logOnlyDirty()
            ->useLogName('teachers')
            ->dontSubmitEmptyLogs();
    }
}
